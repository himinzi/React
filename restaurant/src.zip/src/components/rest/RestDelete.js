function RestDelete(){
    return(
        <>
            <h1>RestDelete</h1>
        </>
    )
}

export default RestDelete;
