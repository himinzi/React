function RestUpdate(){
    return(
        <>
            <h1>RestUpdate</h1>
        </>
    )
}

export default RestUpdate;
