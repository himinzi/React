function RestInsert(){
    return(
        <>
            <h1>RestInsert</h1>
        </>
    )
}

export default RestInsert;
