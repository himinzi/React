function RestOne(){
    return(
        <>
            <h1>RestOne</h1>
        </>
    )
}

export default RestOne;
