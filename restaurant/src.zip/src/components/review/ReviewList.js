import { useState, useEffect } from "react";
import { Link } from 'react-router-dom';
import axios from 'axios';

function RestList(){
    return(
        <>
            <h1>RestList</h1>
        </>
    )
}

export default RestList;
