function Mypage(){
    
    return(
        <>
            <h1>Mypage</h1>
            
        </>
    )
}

export default Mypage;
